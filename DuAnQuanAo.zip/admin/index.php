<?php
include_once("Controller/DanhMucController.php");

$danhMuc = new DanhMucController();
if(isset($_GET['action']) && $_GET['action'] != "") {
$action = $_GET['action'];
    switch($action) {
        //danhmuc
        case "listdanhmuc":
            $danhMuc->index();
            break;
        case "createdanhmuc":
            $danhMuc->create();
            break;
        case "storedanhmuc":
            $danhMuc->store();
            break;
        case "editdanhmuc":
            $danhMuc->edit();
            break;
        case "updatedanhmuc":
            $danhMuc->update();
            break;
        case "deletedanhmuc":
            $danhMuc->delete();
            break;
        case "restoredanhmuc":
            $danhMuc->restore();
            break;
    }
} else {
    $danhMuc->index();
}

?>